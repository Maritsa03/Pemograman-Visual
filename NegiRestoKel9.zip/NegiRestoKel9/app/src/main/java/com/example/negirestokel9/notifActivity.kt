package com.example.negirestokel9

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class notifActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notif)
    }
    fun btnBalik(view: View) {
        val intent = Intent(this@notifActivity, MainActivity::class.java)
        startActivity(intent)
    }
}