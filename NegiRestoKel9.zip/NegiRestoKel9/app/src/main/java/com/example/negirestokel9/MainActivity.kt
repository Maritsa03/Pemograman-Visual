package com.example.negirestokel9

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun buttonGambar(view: View) {
        val intent = Intent(this@MainActivity, activity_burger::class.java)
        startActivity(intent)
    }
    fun btnGambar(view: View) {
        val intent = Intent(this@MainActivity, notifActivity::class.java)
        startActivity(intent)
    }
}